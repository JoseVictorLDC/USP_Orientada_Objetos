#include <iostream>
#include <string>
using namespace std;

class Produto {
public:
    string nome = "";
    double preco = 0.0;
    double desconto = 0.0;
    double calcularValorDeVenda();
    void imprimir();
};

// Implementar os metodos da classe Produto
double Produto::calcularValorDeVenda(){
    return preco - preco*desconto;

}

void Produto::imprimir() {
    cout << "Produto: " << nome << " custa " << calcularValorDeVenda() << endl;

}


class Pedido {
public:
    Produto *produto1 = nullptr;
    Produto *produto2 = nullptr;
    int quantidade1 = 0;
    int quantidade2 = 0;

    bool adicionar(Produto *produto, int quantidade);
    double calcularPrecoTotal();
    void imprimir();
};

// Implementar os metodos da classe Pedido
bool Pedido::adicionar(Produto *produto, int quantidade) {
    if (produto1 == nullptr) {
        this->produto1 = produto;
        this->quantidade1 = quantidade;
        return 1;
    }

    else if (produto2 == nullptr) {
        this->produto2 = produto;
        this->quantidade2 = quantidade;
        return 1;
    } 

    else {
        return 0;
    }

}

double Pedido::calcularPrecoTotal() {
    double precoTotal = 0;

    if (produto1 == nullptr && produto2 == nullptr) {
        return precoTotal;
    }

    if (produto1 != nullptr && produto2 == nullptr) {
        precoTotal = (produto1->calcularValorDeVenda())*(quantidade1);
        return precoTotal;
    }

    if (produto1 != nullptr && produto2 != nullptr) {
        precoTotal = (produto1->calcularValorDeVenda())*(quantidade1) + (produto2->calcularValorDeVenda())*(quantidade2);
        return precoTotal;
    }

}

void Pedido::imprimir() {
    cout << "Pedido: Preco total: " << calcularPrecoTotal() << endl;

}

void teste2() {
    // Implemente a funcao teste do exercicio 02 segundo o enunciado
    Produto *TV = new Produto;
    TV -> nome = "TV";
    TV -> preco = 1000.0;
    TV -> desconto = 0.20;
    TV -> imprimir();

    Produto *SuporteTV = new Produto;
    SuporteTV -> nome = "Suporte para TV";
    SuporteTV -> preco = 150.0;
    SuporteTV -> desconto = 0.05;
    SuporteTV -> imprimir();

    Pedido *TVs = new Pedido;
    TVs -> adicionar(TV, 1);
    TVs -> adicionar(SuporteTV, 2);
    TVs -> imprimir();

}

int main() {
    teste2();
    return 0;
}
