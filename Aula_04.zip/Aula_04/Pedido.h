#ifndef PEDIDO_H
#define PEDIDO_H
#define MAXIMO_DE_PRODUTOS 10
#include "Produto.h"
#include <string>
using namespace std;

class Pedido {
private:
    Produto* produtos[MAXIMO_DE_PRODUTOS];
    int quantidade = 0;

public:
    bool adicionar(Produto* produto);
    double getPrecoTotal();
    void setPrecoTotal(Produto* precoProduto);
    void imprimir();
};
#endif