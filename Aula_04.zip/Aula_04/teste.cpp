#include <iostream>
#include <string>
#include "Pedido.h"
#include "Produto.h"

void teste2() {
    Produto *agua = new Produto;
    agua -> setNome("agua");
    agua -> setPreco(4.90);  

    Produto *desodorante = new Produto;
    desodorante -> setNome("desodorante");
    desodorante -> setPreco(15.59);

    Pedido *pedido = new Pedido;
    pedido -> adicionar(agua);
    pedido -> adicionar(desodorante);

    pedido -> getPrecoTotal();
    pedido -> imprimir();
}

