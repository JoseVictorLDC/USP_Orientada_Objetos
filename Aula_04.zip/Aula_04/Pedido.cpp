#include "Pedido.h"
#include "Produto.h"
#include <iostream>

bool Pedido::adicionar(Produto* produto){
    if (quantidade < MAXIMO_DE_PRODUTOS) {
        for (int i = 0; i < quantidade; i++) {
            if (this->produtos[i] == produto) {
                return false;
            }
        }
        this->produtos[quantidade] = produto;
        this->quantidade++;
        return true;
    }
    return false;
}

double Pedido::getPrecoTotal(){
double precoTotal = 0;

    for(int i = 0; i < quantidade; i++) {
    precoTotal += produtos[i] -> getPreco(); 
    }

    return precoTotal;
}

void Pedido::imprimir(){
    cout << "Pedido com " << this->quantidade << " produtos - " << getPrecoTotal() << " reais no total" << endl;
    for(int i = 0; i < quantidade; i++) {
    produtos[i] -> imprimir(); 
    }
}