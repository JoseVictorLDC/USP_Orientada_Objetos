#include <iostream>
#include "Produto.h"

string Produto::getNome() {
    return this->nome;
}

double Produto::getPreco(){
    return this->preco;
}

void Produto::setNome(string nomeAtual){
    this->nome = nomeAtual;
}

void Produto::setPreco(double precoAtual){
    this->preco = precoAtual;
}

void Produto::imprimir() {
    cout << this->nome << " - " << this->preco << " reais" << endl;
}