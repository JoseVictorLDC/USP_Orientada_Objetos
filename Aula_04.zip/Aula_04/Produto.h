#ifndef PRODUTO_H
#define PRODUTO_H
#include <string>
using namespace std;

class Produto {
    private:
    string nome;
    double preco;

    public:
    string getNome();
    double getPreco();
    void setNome(string nomeAtual);
    void setPreco(double precoAtual);
    void imprimir();

};
#endif