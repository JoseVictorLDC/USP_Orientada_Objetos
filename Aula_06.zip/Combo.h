#ifndef COMBO_H
#define COMBO_H
#include <string>
#include "Produto.h"

using namespace std;

class Combo: public Produto {
private:
    string nome;
    double desconto;
    int quantidadeDeProdutos = 0;
    Produto **p;
public:
    Combo(string nome, Produto **p, int quantidadeDeProdutos, double desconto);
    virtual ~Combo();
    Produto **getProdutos();
    int getQuantidadeDeProdutos();
    double getDesconto();
};
#endif