#include "Produto.h"
#include "Combo.h"
#include "Pedido.h"

void teste1() {
Produto* pipocaGrande = new Produto("Pipoca Grande", 20.0);
Produto* cocaCola = new Produto("Coca Cola", 15.0);

Produto* Produtos[] = {pipocaGrande, cocaCola};
Combo* Combo2 = new Combo("Combo 2", Produtos, 2, 0.2);
Combo2 -> imprimir();
delete Combo2;
delete pipocaGrande;
delete cocaCola;
}
void teste2() {
Produto* pipocaGrande = new Produto("Pipoca Grande", 20.0);
Produto* cocaCola = new Produto("Coca Cola", 15.0);
Produto* Produtos[] = {pipocaGrande, cocaCola};
Combo* Combo2 = new Combo("Combo 2", Produtos, 2, 0.2);

Produto* pipocaPequena = new Produto("Pipoca Pequena", 15.0);
Produto* pepsi500ml = new Produto("Pepsi 500ml", 10.0);

Pedido* pedido = new Pedido(3);
pedido -> adicionar(Combo2);
pedido -> adicionar(pipocaPequena);
pedido -> adicionar(pepsi500ml);

pedido -> imprimir();
pedido -> remover(pipocaPequena);
pedido -> imprimir();

delete pedido;
delete Combo2;
delete pipocaGrande;
delete cocaCola;
delete pipocaPequena;
delete pepsi500ml;
}