#include "Pedido.h"

Pedido::Pedido(int quantidadeMaxima) {
    this->produtos = new Produto*[quantidadeMaxima];
}

Pedido::~Pedido() {
}

bool Pedido::adicionar(Produto *p) {
    if (quantidadeDeProdutos > quantidadeMaxima){
        return false;
    }
    for(int i = 0; i < quantidadeDeProdutos; i++) {
        if (produtos[i] == p)
            return false;
    }
    produtos[quantidadeDeProdutos] = p;
    valorTotal += p->getPreco();
    quantidadeDeProdutos++;
    return true;
}

bool Pedido::remover(Produto *p) {
    for(int i = 0; i < quantidadeDeProdutos; i++) {
        if (produtos[i] == p) {
            valorTotal -= produtos[i] ->getPreco();
            for(int j = -1; j <= i; j++) {
                produtos[i+j+1] = produtos[i+j+2];
            }  
            quantidadeDeProdutos--;
            return true; 
        }   
    }
    return false;

}

Produto** Pedido::getProdutos() {
    return produtos;
}

int Pedido::getQuantidadeDeProdutos() {
    return  quantidadeDeProdutos;
}

double Pedido::getValor() {
    return valorTotal;
}

void Pedido::imprimir() {
    cout << "Pedido com " << getQuantidadeDeProdutos() << " produto(s) - " << getValor() << " reais" << endl;
    for (int i = 0; i < getQuantidadeDeProdutos(); i++)
        getProdutos()[i]->imprimir();
    cout << endl;
}