#include "Combo.h"
#include <iostream>
#include <string>
using namespace std;

Combo::Combo(string nome, Produto **p, int quantidadeDeProdutos, double desconto): Produto(nome, 0) { 
    for (int i = 0; i< quantidadeDeProdutos; i++) {
        preco += p[i] -> getPreco();
    }
    this->desconto = desconto;
    this->preco *= (1 - desconto);
    this->p = p;
    this->nome = nome;
    this->quantidadeDeProdutos = quantidadeDeProdutos;
}

Combo::~Combo() {
}

Produto** Combo::getProdutos() {
    return p;
}

int Combo::getQuantidadeDeProdutos() {
    return quantidadeDeProdutos;
}

double Combo::getDesconto() {
    return desconto;
}
