#ifndef CIRCUITO_H
#define CIRCUITO_H

class Circuito
{
protected:
    static int ultimoID;
    int id;

public:
    Circuito();
    virtual ~Circuito() = 0;
    int getID();
    virtual void imprimir();
    static int getUltimoID();
};

#endif