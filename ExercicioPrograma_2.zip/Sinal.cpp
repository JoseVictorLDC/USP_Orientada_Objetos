#include "Sinal.h"
#include "Grafico.h"

#include <stdexcept>
#include <iostream>
using namespace std;

Sinal::Sinal(double *sequencia, int comprimento) : sequencia(sequencia), comprimento(comprimento), grafico(nullptr)
{
    if (comprimento <= 0)
        throw new invalid_argument("Comprimento deve ser maior que zero");

    sequenciaAux = new double[comprimento];
    for (int i = 0; i < comprimento; i++)
    {
        sequenciaAux[i] = sequencia[i];
    }
}

Sinal::Sinal(double constante, int comprimento) : constante(constante), comprimento(comprimento), grafico(nullptr)
{
    if (comprimento <= 0)
        throw new invalid_argument("Comprimento deve ser maior que zero");

    sequenciaAux = new double[comprimento];
    for (int i = 0; i < comprimento; i++)
    {
        sequenciaAux[i] = constante;
    }
}

Sinal::~Sinal()
{
    // delete sequenciaAux alocado dinamicamente no cosntrutor
    delete[] sequenciaAux;
    delete grafico;
}

double *Sinal::getSequencia()
{
    return sequenciaAux;
}

int Sinal::getComprimento()
{
    return comprimento;
}

void Sinal::imprimir(string nomeDoSinal)
{
    grafico = new Grafico(this->nomeDoSinal, this->getSequencia(), this->getComprimento());
    grafico->plot();
}

void Sinal::imprimir()
{
    for (int i = 0; i < comprimento; i++)
    {
        cout << i << "- " << this->getSequencia()[i] << endl;
    }
    cout << "--" << endl;
}

void Sinal::imprimir(int tamanho)
{
    for (int i = 0; i < tamanho; i++)
    {
        cout << i << "- " << this->getSequencia()[i] << endl;
    }
    cout << "--" << endl;
}