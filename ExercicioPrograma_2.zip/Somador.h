#ifndef SOMADOR_H
#define SOMADOR_H

#include "CircuitoMISO.h"
#include "Sinal.h"

class Somador : public CircuitoMISO // herança da classe CircuitoMISO
{
private:
  double *sequencia;

public:
  Somador();
  virtual ~Somador();
  Sinal *processar(Sinal *sinalIN1, Sinal *sinalIN2); // redefinição do método processar da superclasse
};
#endif