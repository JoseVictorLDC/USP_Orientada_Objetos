#include "Amplificador.h"
#include "Sinal.h"

Amplificador::Amplificador(double ganho) : CircuitoSISO(), g(ganho), sequencia(nullptr)
{
}

Amplificador::~Amplificador()
{
    // delete em sequencia alocado dinamicamente no processar
    delete[] sequencia;
}

Sinal *Amplificador::processar(Sinal *sinalIN)
{
    if (sequencia != nullptr)
        delete[] sequencia; // delete no vetor alocado dinamicamente no processar anterior (se houver)

    sequencia = new double[sinalIN->getComprimento()];
    for (int i = 0; i < sinalIN->getComprimento(); i++)
    {
        sequencia[i] = (sinalIN->getSequencia())[i] * g;
    }
    return new Sinal(sequencia, sinalIN->getComprimento());
}

void Amplificador::setGanho(double ganho)
{
    this->g = ganho;
}

double Amplificador::getGanho()
{
    return g;
}