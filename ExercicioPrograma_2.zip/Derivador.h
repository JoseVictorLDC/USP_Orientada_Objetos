#ifndef DERIVADOR_H
#define DERIVADOR_H

#include "CircuitoSISO.h"
#include "Sinal.h"

class Derivador : public CircuitoSISO // herança da classe CircuitoSISO
{
private:
    double *sequencia;

public:
    Derivador();
    virtual ~Derivador();
    Sinal *processar(Sinal *sinalIN); // redefinição do método processar da superclasse
};

#endif