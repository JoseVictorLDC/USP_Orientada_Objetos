#ifndef PERSISTENCIADEMODULO_H
#define PERSISTENCIADEMODULO_H

#include "ModuloEmParalelo.h"
#include "ModuloRealimentado.h"
#include "Derivador.h"

class PersistenciaDeModulo
{
private:
    string nomeDoArquivo;

public:
    PersistenciaDeModulo(string nomeDoArquivo);
    virtual ~PersistenciaDeModulo();
    void salvarEmArquivo(Modulo *mod);
    Modulo *lerDeArquivo();
};

#endif