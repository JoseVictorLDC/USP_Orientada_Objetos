#ifndef AMPLIFICADOR_H
#define AMPLIFICADOR_H

#include "CircuitoSISO.h"
#include "Sinal.h"

class Amplificador : public CircuitoSISO // herança da classe CircuitoSISO
{
private:
  double g;
  double *sequencia;

public:
  Amplificador(double ganho);
  virtual ~Amplificador();
  Sinal *processar(Sinal *sinalIN); // redefinição do método processar da superclasse
  void setGanho(double ganho);
  double getGanho();
};

#endif