#include "Circuito.h"

#include <iostream>
using namespace std;

int Circuito::ultimoID = 0;

Circuito::Circuito()
{
    id = ultimoID + 1;
    ultimoID++;
}

Circuito::~Circuito()
{
}

int Circuito::getID()
{
    return id;
}

void Circuito::imprimir()
{
    cout << "Circuito com ID " << id << endl;
}

int Circuito::getUltimoID()
{
    return Circuito::ultimoID;
}