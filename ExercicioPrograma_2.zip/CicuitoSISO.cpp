#include "CircuitoSISO.h"


CircuitoSISO::CircuitoSISO() : Circuito()
{
}

CircuitoSISO::~CircuitoSISO()
{
}
