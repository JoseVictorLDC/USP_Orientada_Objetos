#ifndef INTEGRADOR_H
#define INTEGRADOR_H

#include "CircuitoSISO.h"
#include "Sinal.h"

class Integrador : public CircuitoSISO // herança da classe CircuitoSISO
{
private:
    double *sequencia;

public:
    Integrador();
    virtual ~Integrador();
    Sinal *processar(Sinal *sinalIN); // redefinição do método processar da superclasse
};

#endif