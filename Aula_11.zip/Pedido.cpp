#include "Pedido.h"
#include "Item.h"
#include <iostream>
#include <stdexcept>
#include <list>
using namespace std;

Pedido::Pedido() : quantidade(0) {
    this->itens = new list<Item*>();
}

Pedido::~Pedido() {
    cout << "Pedido com " << quantidade << " item(ns) destruido" << endl;

    for (list<Item*>::iterator i = itens->begin(); i != itens->end(); i++) {
    delete (*i);
    }
    delete itens;
}

void Pedido::adicionar(Produto* produto, int quantidade) {
    for (list<Item*>::iterator i = itens->begin(); i != itens->end(); i++) {
        if (produto == (*i)->getProduto()) {
        throw new invalid_argument("Produto ja existente");
        }
    }
    Item *item = new Item(produto, quantidade);
    itens->push_back(item);
    this->quantidade++;
}

list<Item*>* Pedido::getItens() {
    return itens;
}

void Pedido::imprimir() {
    cout << "Pedido - " << quantidade << " item(ns)" << endl;
    for (list<Item*>::iterator i = itens->begin(); i != itens->end(); i++) {
    (*i)->imprimir();
    }
}