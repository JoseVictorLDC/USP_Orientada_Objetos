#ifndef COMBO_H
#define COMBO_H
#include "Produto.h"
#include <string>
#include <vector>
using namespace std;


class Combo : public Produto {
private:
    vector <Produto*>* produtos;
public:
    Combo(string nome);
    virtual ~Combo();
    void adicionar(Produto* p);
    double getPreco();

    vector <Produto*>* getProdutos();
    void imprimir();
};

#endif