#include "Combo.h"
#include "Produto.h"
#include "Pedido.h"
#include <stdexcept>
#include <iostream>

void teste1() {
    Combo *burguerEBebida = new Combo("Burguer e bebida");

    try {
    Produto *xBacon = new Produto("X-Bacon", 24.99);
    burguerEBebida->adicionar(xBacon);
    Produto *cocaColaLata = new Produto("Coca-Cola Lata", 4.49);
    burguerEBebida->adicionar(cocaColaLata);
    burguerEBebida->imprimir();

    delete burguerEBebida;
    delete xBacon;
    delete cocaColaLata;
    } catch (invalid_argument *e) {
        cout << e->what() << endl;
        delete e;
    }
}

void teste2() {
    Pedido *pedido = new Pedido();

    try {
    Combo *burguerEBebida = new Combo("Burguer e bebida");
    Produto *xBacon = new Produto("X-Bacon", 24.99);
    burguerEBebida->adicionar(xBacon);
    Produto *cocaColaLata = new Produto("Coca-Cola Lata", 4.49);
    burguerEBebida->adicionar(cocaColaLata);

    pedido->adicionar(burguerEBebida, 2);
    Produto *sundae = new Produto("Sundae", 7.85);
    pedido->adicionar(sundae, 2);

    pedido->imprimir();

    delete pedido;
    delete burguerEBebida;
    delete xBacon;
    delete cocaColaLata;
    delete sundae;
    } catch (invalid_argument *e) {
        cout << e->what() << endl;
        delete e;
    }
}