#include "Pedido.h"
#include "ProdutoComDesconto.h"
#include <iostream>
using namespace std;

Pedido::Pedido(int quantidadeMaxima) : itens(new Item*[quantidadeMaxima]), quantidadeMaxima(quantidadeMaxima), quantidade(0) {}

Pedido::~Pedido() {
    cout << "Pedido com " << quantidade << " item(ns) destruido" << endl;
    for (int i = 0; i < quantidade; ++i) delete itens[i];
    delete[] itens;
}

Item** Pedido::getItens() {
    return itens;
}

int Pedido::getQuantidadeItens() {
    return quantidade;
}

ProdutoComDesconto Pedido::**getProdutosComDesconto(int& quantidade) {
    ProdutoComDesconto **produtosComDesconto[] = new ProdutoComDesconto*[quantidadeMaxima];
    quantidade = 0;

    for (int i=0; i<quantidade; i++) {
        if ((itens[i]->getProduto())->desconto != 0)
            produtosComDesconto[quantidade] = itens[i];
            quantidade++;
    }
    if (quantidade = 0) {
        return NULL;
    }
    return produtosComDesconto;
}

bool Pedido::adicionar(Produto *produto) {
    Pedido::adicionar(produto, 1);
}

bool Pedido::adicionar(Produto* produto, int quantidade) {
    if (this->quantidade >= quantidadeMaxima)
        return false;

    itens[this->quantidade++] = new Item(produto, quantidade);
    return true;
}

double Pedido::calcularPrecoTotal() {
    double precoTotal = 0;
    for (int i = 0; i < quantidade; i++)
        precoTotal += itens[i]->calculaPrecoTotal();

    return precoTotal;
}

void Pedido::imprimir() {
    cout << "Pedido com " << this->quantidade << " item(ns)" << endl;
    for (int i=0; i<quantidade; i++) {
        cout << itens[i]->getQuantidade() << " unidade(s) de " << (itens[i]->getProduto())->getNome() << " - " << (itens[i]->getProduto())->getPreco() << " reais cada" << endl;
    }
}