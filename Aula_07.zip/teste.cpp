#include <iostream>
#include "Produto.h"
#include "Item.h"
#include "Pedido.h"
#include "ProdutoComDesconto.h"

void teste1(){
Pedido *pedido = new Pedido(3);
Produto *balaDeGoma = new Produto("Bala de goma", 3.50);
pedido->adicionar(balaDeGoma);

Produto *chocolate = new Produto("Chocolate", 5.20);
pedido->adicionar(chocolate, 4);

pedido->imprimir();
delete pedido;
delete balaDeGoma;
delete chocolate;
}

void teste2(){
Pedido *pedido = new Pedido(2);
Produto *linguica = new Produto("Linguica", 20.90);
pedido->adicionar(linguica, 2);

ProdutoComDesconto *picanha = new ProdutoComDesconto("Chocolate", 70.49, 0.1);
pedido->adicionar(picanha);

pedido->imprimir();
delete pedido;
delete linguica;
delete picanha;

}

void teste3() {
Pedido *pedido = new Pedido(2);
int quantidade;
cout << pedido->getProdutosComDesconto(quantidade) << endl;

ProdutoComDesconto *refrigerante = new ProdutoComDesconto("Refrigerante", 7.80);
pedido->adicionar(refrigerante, 2);
cout << pedido->getProdutosComDesconto(quantidade) << endl;

ProdutoComDesconto *pizza = new ProdutoComDesconto("Pizza", 40.99);
pedido->adicionar(pizza, 2);
cout << pedido->getProdutosComDesconto(quantidade) << endl;

delete pedido;
delete refrigerante;
delete pizza;
}