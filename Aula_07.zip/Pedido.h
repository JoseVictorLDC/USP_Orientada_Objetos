#ifndef PEDIDO_H
#define PEDIDO_H
#include "Produto.h"
#include "Item.h"

class Pedido {
public:
    Pedido(int quantidadeMaxima);
    ~Pedido();

    bool adicionar(Produto *produto);
    bool adicionar(Produto *produto, int quantidade); 

    Item** getItens();
    int getQuantidadeItens();
    ProdutoComDesconto** getProdutosComDesconto(int& quantidade);

    double calcularPrecoTotal();
    void imprimir();

    Item** itens;
    int quantidadeMaxima;
private:
    int quantidade;
};

#endif // PEDIDO_H
