#include <iostream>
#include <stdexcept>
#include "Produto.h"
#include "Pedido.h"
#include "PersistenciaDeProduto.h"
using namespace std;

void teste1() {
    Produto *lasanha = new Produto("Lasanha", 20.0);
    Produto *batata = new Produto("Batata", 5.0);

    PersistenciaDeProduto *persistencia = new PersistenciaDeProduto("teste1.txt");
    persistencia->inserir(lasanha);
    persistencia->inserir(batata);

    delete lasanha;
    delete batata;
    delete persistencia;
}

void teste2() {
    PersistenciaDeProduto *persistencia = new PersistenciaDeProduto("teste2.txt");
    Pedido *pedidoTeste;

    try {
        pedidoTeste = persistencia->obter();
        if (pedidoTeste != NULL) {
            pedidoTeste->imprimir();
        }
        delete pedidoTeste;
    } catch (invalid_argument *e) {
        cout << e->what() << endl;
        delete e;
    } catch (logic_error *e) {
        cout << e->what() << endl;
        delete e;
    }

    delete persistencia;
}