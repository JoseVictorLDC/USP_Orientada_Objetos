void teste1();
void teste2();

int main() { 
    teste2(); //Substitua pelo teste que deseja efetuar
    return 0; 
}