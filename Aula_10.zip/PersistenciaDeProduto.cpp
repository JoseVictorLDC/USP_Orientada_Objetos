#include "PersistenciaDeProduto.h"
#include "Pedido.h"
#include "Produto.h"
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

PersistenciaDeProduto::PersistenciaDeProduto(string arquivo){
    this->arquivo = arquivo;
}

PersistenciaDeProduto::~PersistenciaDeProduto(){
}

void PersistenciaDeProduto::inserir(Produto *produto){
    ofstream ostream;
    ostream.open(this->arquivo, ios_base::app);
    ostream << produto->getNome() << endl << produto->getPreco() << endl;
}

Pedido* PersistenciaDeProduto::obter(){
    ifstream istream;
    string nome;
    double preco;
    Pedido *pedido = new Pedido(10);

    istream.open(this->arquivo, ios_base::out);

    if(istream.fail()) {
        delete pedido;
        throw invalid_argument("Erro de leitura");
    }

    istream >> nome >> preco;
    while (istream) {
        Produto *produto = new Produto(nome, preco);
        pedido->adicionar(produto);
        istream >> nome >> preco;
    }

    if (pedido->getQuantidadeDeProdutos() == 0) {
        delete pedido;
        return NULL;
    }

    if (!istream.eof()) {
        delete pedido;
        throw logic_error("Arquivo em formatacao inesperada");
    }

    return pedido;
}
