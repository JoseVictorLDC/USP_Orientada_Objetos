#include <stdexcept>
#include <iostream>
#include "Produto.h"
#include "Pedido.h"
#include "ProdutoIndisponivel.h"
using namespace std;

void teste1(){
    try {
    Produto *produtoTeste = new Produto ("Produto Teste", -1);      
    } catch (invalid_argument *e) {
        cout << e->what() << endl;
        delete e;
    }

}

void teste2(){
    Produto *gatorade = new Produto ("Gatorade", 7.50);
    cout << gatorade->getPreco() << endl;
    gatorade->setDisponivel(false);

    try {
        gatorade->getPreco();
    } catch (ProdutoIndisponivel *e) {
        cout << e->what() << endl;
    }

}

void teste3(){
    Pedido *pedido = new Pedido(4);
    Produto *cerveja = new Produto ("Cerveja", 4.35);
    Produto *bis = new Produto ("Bis", 3.90);
    Produto *frigideira = new Produto ("Frigideira", 80.79);
    Produto *vassoura = new Produto ("Vassoura", 30.50);

    pedido->adicionar(cerveja, 5);
    pedido->adicionar(bis, 2);
    pedido->adicionar(frigideira, 1);
    pedido->adicionar(vassoura, 1);

    cout << pedido->calcularPrecoTotal() << endl;

    cerveja->setDisponivel(false);
    frigideira->setDisponivel(false);

    cout << pedido->calcularPrecoTotal() << endl;

    bis->setDisponivel(false);
    vassoura->setDisponivel(false);

    cout << pedido->calcularPrecoTotal() << endl;
}
