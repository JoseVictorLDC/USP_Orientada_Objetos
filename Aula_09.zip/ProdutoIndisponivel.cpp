#include "ProdutoIndisponivel.h"
#include "Produto.h"
#include <iostream>

ProdutoIndisponivel::ProdutoIndisponivel (string mensagem) : logic_error(mensagem) {

}

ProdutoIndisponivel::~ProdutoIndisponivel() {
    
}