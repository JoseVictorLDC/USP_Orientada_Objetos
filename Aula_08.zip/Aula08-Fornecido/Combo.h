#ifndef COMBO_H
#define COMBO_H

#include "Produto.h"
#include "ProdutoNormal.h"

class Combo: public Produto {

private:
    int quantidadeMaxima;
    int quantidadeDeProdutos = 0;
    ProdutoNormal **vetorProdutosNormais;

public:
    Combo(string nome, int quantidadeMaxima);
    virtual ~Combo();

    bool adicionar(ProdutoNormal *ep);
    ProdutoNormal **getProdutosNormais();
    int getQuantidadeDeProdutosNormais();

    void imprimir();
};
#endif