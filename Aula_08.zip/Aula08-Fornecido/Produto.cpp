#include <iostream>
#include "Produto.h"

using namespace std;

int Produto::staticID = 0;

Produto::Produto(string nome, double preco) : nome(nome), preco(preco) {
    this->objetoID = Produto::staticID;
    Produto::staticID++;
}

Produto::~Produto() {
}

double Produto::getPreco() {
    return preco;
}
string Produto::getNome() {
    return nome;
}
int Produto::getProximoId() {
    return Produto::staticID;
}
int Produto::getId() {
    return this->objetoID;
}