#include "ProdutoNormal.h"
#include "Combo.h"

void teste1() {
    ProdutoNormal *temakiAtum = new ProdutoNormal("Temaki Atum", 20.0);
    ProdutoNormal *shimeji = new ProdutoNormal("Shimeji", 15.0);
    ProdutoNormal *sashimi = new ProdutoNormal("Sashimi", 15.0);
    Combo *sushiExecutivo = new Combo("Sushi Executivo", 3);

    sushiExecutivo->adicionar(temakiAtum);
    sushiExecutivo->adicionar(shimeji);
    sushiExecutivo->adicionar(sashimi);

    sushiExecutivo->imprimir();

    delete sushiExecutivo;
    delete temakiAtum;
    delete shimeji;
    delete sashimi;
}

void teste2() {
    ProdutoNormal *temakiAtum = new ProdutoNormal("Temaki Atum", 20.0);
    ProdutoNormal *shimeji = new ProdutoNormal("Shimeji", 15.0);
    ProdutoNormal *sashimi = new ProdutoNormal("Sashimi", 15.0);
    Combo *sushiExecutivo = new Combo("Sushi Executivo", 3);

    sushiExecutivo->adicionar(temakiAtum);
    sushiExecutivo->adicionar(shimeji);
    sushiExecutivo->adicionar(sashimi);

    cout << temakiAtum->getId() << endl;
    cout << shimeji->getId() << endl;
    cout << sashimi->getId() << endl;
    cout << sushiExecutivo->getId() << endl;

    delete sushiExecutivo;
    delete temakiAtum;
    delete shimeji;
    delete sashimi;
}