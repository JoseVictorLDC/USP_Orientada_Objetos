#include "Combo.h"

#include <string>
using namespace std;

Combo::Combo(string nome, int quantidadeMaxima): Produto(nome, 0) {
	this->quantidadeMaxima = quantidadeMaxima;
	vetorProdutosNormais = new ProdutoNormal*[quantidadeMaxima];
}

Combo::~Combo() {
    cout << "Combo " << this->getNome() << " destruido" << endl;
}

bool Combo::adicionar(ProdutoNormal *ep) {
	if (getQuantidadeDeProdutosNormais() == quantidadeMaxima) {
		return false;
	}
	else {
		vetorProdutosNormais[this->quantidadeDeProdutos] = ep;
		this->quantidadeDeProdutos++;
		this->preco += ep->getPreco();
		return true;
	}
}

ProdutoNormal** Combo::getProdutosNormais() {
	if (getQuantidadeDeProdutosNormais() != 0) {
		return this->vetorProdutosNormais;
	}
	return NULL;
}

int Combo::getQuantidadeDeProdutosNormais() {
	return quantidadeDeProdutos;
}

void Combo::imprimir() {
	cout << getNome() << " - " << getPreco() << " reais" << " - " << getQuantidadeDeProdutosNormais() << " produtos normais" << endl;
	for (int i=0; i < quantidadeDeProdutos; i++) {
		cout << "\t" << i+1 << ": " << getProdutosNormais()[i]->getNome() << " - " << getProdutosNormais()[i]->getPreco() << " reais" << endl;
	}
}