#ifndef PROD_H
#define PROD_H

#include <string>
using namespace std;

class Produto {
protected:
    string nome;
    double preco;
    int objetoID = -1;
    static int staticID;

public:
    Produto(string nome, double preco);
    virtual ~Produto();
    double getPreco();
    string getNome();
    virtual void imprimir() = 0;

    static int getProximoId();
    int getId();
};
#endif