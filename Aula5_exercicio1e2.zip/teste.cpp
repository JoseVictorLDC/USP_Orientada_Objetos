#include "Item.h"
#include "Produto.h"
#include "Pedido.h"
#include <iostream>
using namespace std;

void teste1() {
Produto *cuecaProduto = new Produto("Cueca", 20.89);
cuecaProduto -> imprimir();

Item *cuecaItem = new Item(cuecaProduto, 5);
cuecaItem -> imprimir();

delete cuecaItem;
delete cuecaProduto;
}

void teste2() {
Produto *Absorvente = new Produto("Absorvente", 10.40);
Produto *Pringles = new Produto("Pringles", 12.37);
Produto *Cookies = new Produto("Cookies", 5.39);

Pedido *Pedido1 = new Pedido(4);
Pedido1 -> adicionar(Absorvente, 1);
Pedido1 -> adicionar(Pringles, 1);
Pedido1 -> adicionar(Cookies, 1);

Pedido *Pedido2 = new Pedido(4);
Pedido2 -> adicionar(Absorvente, 1);
Pedido2 -> adicionar(Cookies, 2);

delete Pedido1;
delete Pedido2;
delete Absorvente;
delete Pringles;
delete Cookies;
}