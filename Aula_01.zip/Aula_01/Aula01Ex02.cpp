/*Faca os includes necessarios*/
#include <iostream>
#include <string>
using namespace std;

bool produtoEstaDisponivel(string produtos[], int quantidadeDisponivel[], int tamanhoDaLista, string produtoBuscado, int quantidadeBuscada) {
    int i;

    for (i=0; i<tamanhoDaLista; i++) {
        if (produtos[i] == produtoBuscado) {
            if (quantidadeDisponivel[i] >= quantidadeBuscada)
                return true;
        }
    }
    
    return false;
}

/*Comente a main para enviar*/
/*int main() {
    string produtos[] = {"Arroz", "feijão"};
    int quantidadeDisponivel[] = {10, 5};

    cout << produtoEstaDisponivel (produtos, quantidadeDisponivel, 2, "Arroz", 12) << endl;
    return 0;
}*/
