/*Faca os includes necessarios*/
#include <iostream>
#include <string>
using namespace std;

double calcularPrecoTotal(string produtos[], double precos[], int quantidadeDeProdutos, string produtosNaSacola[], int quantidadeDeProdutosNaSacola) {
    int i, j;
    double precoTotal = 0;

    for (i=0; i<quantidadeDeProdutosNaSacola; i++) {
        for (j=0; j<quantidadeDeProdutos; j++) {
            if (produtosNaSacola[i] == produtos[j]) {
                precoTotal = precoTotal + precos[j];
            }
        }
    }

    return precoTotal;
}

/*Comente a main para enviar*/
/*int main(){
    int quantidadeDeProdutos = 2;
    string produtos[] = {"Arroz", "Feijao" };
    double precos[] = {20.0, 10.0};
    int quantidadeDeProdutosNaSacola = 3;
    string produtosNaSacola[] = {"Arroz", "Batata", "Feijao"};

    cout << calcularPrecoTotal(produtos, precos, quantidadeDeProdutos, produtosNaSacola, quantidadeDeProdutosNaSacola);

    return 0;
}*/
