/*Faca os includes necessarios*/
#include <iostream>
using namespace std;

double calculaTaxaDeEntrega(int tipoDePagamento, bool temCupom, int distancia) {
    //Considerando distancia < 1
    if (distancia < 1) 
        return 0;

    //Desconto para PIX
    if (tipoDePagamento == 1) {
        if (distancia > 5)
            return 0.95*1.5*distancia;

        return 1.5*distancia;  
    }

    //Ticket alimentação é sempre valor normal
    else if (tipoDePagamento == 2) {
        return 1.5*distancia;        
    }

    // Cartão de crédito e a possibilidade de cupom
    else {
        if (temCupom == true && distancia <= 5)
            return 0;

        return 1.5*distancia;        
    }
}

/*Comente a main para enviar*/
/* int main(){

    cout << calculaTaxaDeEntrega(1, false, 10) << endl;
    cout << calculaTaxaDeEntrega(2, false, 5) << endl;
    cout << calculaTaxaDeEntrega(3, true, 9) << endl;
return 0;
} */
