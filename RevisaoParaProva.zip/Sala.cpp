#include "Sala.h"
#include <stdexcept>
#include <iostream>

using namespace std;

Sala::Sala(string nome, int metragem) {
    if (metragem <= 0) {
        throw new invalid_argument("Metragem invalida");
    }
    this->nome = nome;
    this->metragem = metragem;
}

Sala::~Sala() {
}

string Sala::getNome() {
    return this->nome;
}

int Sala::getMetragem() {
    return this->metragem;
}

void Sala::imprimir() {
    cout << "Sala " << getNome() << " (" << getMetragem() << ") - R$ " << getPreco() << endl;
}

// IMPLEMENTE OS DEMAIS METODOS
