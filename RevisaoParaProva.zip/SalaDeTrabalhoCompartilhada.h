#ifndef SALADETRABALHOCOMPARTILHADA_H
#define SALADETRABALHOCOMPARTILHADA_H

#include "Mesa.h"
#include "SalaDeTrabalho.h"

#include <string>
#include <vector>

using namespace std;

// COMPLETE A DEFINICAO DA CLASSE
class SalaDeTrabalhoCompartilhada : public SalaDeTrabalho {
private:
    vector<Mesa*>* mesasReserva;
    double preco;

public:
    SalaDeTrabalhoCompartilhada(string nome, int metragem);
    virtual ~SalaDeTrabalhoCompartilhada();

    void reservar(Mesa* m);
    void reservar();

    vector<Mesa*>* getMesasReservadas();

    double getPreco();
};

#endif // SALADETRABALHOCOMPARTILHADA_H
