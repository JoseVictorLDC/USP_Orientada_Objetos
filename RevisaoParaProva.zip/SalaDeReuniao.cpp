#include "SalaDeReuniao.h"
#include <stdexcept>

using namespace std;

double SalaDeReuniao::precoPorMetroQuadrado = 10.0;

SalaDeReuniao::SalaDeReuniao(string nome, int metragem) : Sala(nome, metragem)
{
}

SalaDeReuniao::~SalaDeReuniao() {
}

void SalaDeReuniao::setPrecoPorMetroQuadrado(double valor) {
    if (valor == 0) {
        throw new invalid_argument ("Valor invalido");
    }

    SalaDeReuniao::precoPorMetroQuadrado = valor;
}

double SalaDeReuniao::getPrecoPorMetroQuadrado() {
    return SalaDeReuniao::precoPorMetroQuadrado;
}

double SalaDeReuniao::getPreco() {
    this->preco = getMetragem()*(SalaDeReuniao::precoPorMetroQuadrado);
    return this->preco;
}