#include <iostream>

#include "Mesa.h"
#include "SalaDeReuniao.h"
#include "SalaDeTrabalho.h"
#include "SalaDeTrabalhoCompartilhada.h"

using namespace std;

void testeP2() {
    try {
    // Crie uma sala de reuniao com nome "A1" e 100m2,
    // colocando-a numa variavel do tipo Sala e a imprima
    SalaDeReuniao *salaDeReuniao = new SalaDeReuniao("A1", 100);
    salaDeReuniao->imprimir();

    // Altere o valor do preco por metro quadrado para 15 das salas de reuniao
    // imprima novamente a sala de reuniao com nome "A1"
    salaDeReuniao->setPrecoPorMetroQuadrado(15);
    salaDeReuniao->imprimir();

    // Crie uma sala de trabalho com nome "A2" e 100m2,
    // colocando-a numa variavel do tipo Sala
    SalaDeTrabalho *salaDeTrabalho = new SalaDeTrabalho("A2", 100);

    // Adicione as seguintes mesas a sala A2
    // Mesa com id 1 e tamanho de 10m2
    // Mesa com id 2 e tamanho de 12m2
    Mesa *mesa1 = new Mesa(1, 10);
    Mesa *mesa2 = new Mesa(2, 12);
    salaDeTrabalho->adicionar(mesa1);
    salaDeTrabalho->adicionar(mesa2);

    // Imprima a sala de trabalho com nome A2
    salaDeTrabalho->imprimir();

    // Crie uma sala de trabalho compartilhada com nome "A3" e 30m2,
    // colocando-a em uma vari�vel do tipo SalaDeTrabalhoCompartilhada
    SalaDeTrabalhoCompartilhada *salaDeTrabalhoCompartilhada = new SalaDeTrabalhoCompartilhada("A3", 30);

    // Adicione as seguintes mesas:
    // Mesa com id 3 e tamanho de 10m2
    // Mesa com id 4 e tamanho de 12m2
    Mesa *mesa3 = new Mesa(3, 10);
    Mesa *mesa4 = new Mesa(4, 12);
    salaDeTrabalhoCompartilhada->adicionar(mesa3);
    salaDeTrabalhoCompartilhada->adicionar(mesa4);

    //  Reserve somente a mesa com id 4 e imprima a sala de trabalho com nome A3.
    salaDeTrabalhoCompartilhada->reservar(mesa4);
    salaDeTrabalhoCompartilhada->imprimir();

    //Destrua todas as salas
    delete salaDeReuniao;
    delete salaDeTrabalho;
    delete salaDeTrabalhoCompartilhada;

    } catch (invalid_argument *e) {
        cout << e->what() << endl;
        delete e;
    } catch (logic_error *e) {
        cout << e->what() << endl;
        delete e;
    }
}
