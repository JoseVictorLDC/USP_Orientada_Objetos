#include "SalaDeTrabalho.h"

#include <algorithm>
#include <stdexcept>

using namespace std;

// ALTERE
SalaDeTrabalho::SalaDeTrabalho(string nome, int metragem) : Sala(nome, metragem) {
}

SalaDeTrabalho::~SalaDeTrabalho() {
    for (vector<Mesa *>::iterator i = mesas->begin(); i != mesas->end(); i++) {
        delete (*i);
    }
    delete mesas;
}

void SalaDeTrabalho::adicionar(Mesa* m) {
    if (m->getTamanho() > (getMetragem() - tamanhoDasMesas)) {
        throw new logic_error("Mesa nao cabe");
    }
    for (vector<Mesa *>::iterator i = mesas->begin(); i != mesas->end(); i++) {
        if (*i == m) {
            throw new logic_error("Mesa ja existente");
        }
    }
    mesas->push_back(m);
    tamanhoDasMesas += m->getTamanho();
    quantidadeDeMesas++;

}

vector<Mesa*>* SalaDeTrabalho::getMesas() {
    return mesas;
}

double SalaDeTrabalho::getPreco() {
    this->preco = 100*quantidadeDeMesas;
    return preco;
}