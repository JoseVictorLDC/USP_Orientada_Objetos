#include "SalaDeTrabalhoCompartilhada.h"

#include <stdexcept>
#include <algorithm>
#include <iostream>

using namespace std;

// ALTERE
SalaDeTrabalhoCompartilhada::SalaDeTrabalhoCompartilhada(string nome, int metragem) : SalaDeTrabalho(nome, metragem) {
}

SalaDeTrabalhoCompartilhada::~SalaDeTrabalhoCompartilhada() {
    delete mesasReserva;
}

void SalaDeTrabalhoCompartilhada::reservar(Mesa* m) {
    for (vector<Mesa *>::iterator i = mesasReserva->begin(); i != mesasReserva->end(); i++) {
        if (*i == m) {
            throw new logic_error("Mesa  ja reservada");
        }
    }
    if (find(getMesas()->begin(), getMesas()->end(), m) != getMesas()->end()) {
        throw new invalid_argument("Mesa nao faz parte da sala");
    }
    mesasReserva->push_back(m);
}

void SalaDeTrabalhoCompartilhada::reservar() {
    try {
        for (vector<Mesa *>::iterator i = mesasReserva->begin(); i != mesasReserva->end(); i++) {
        reservar(*i);
        }
    } catch (invalid_argument *e) {
        cout << e->what() << endl;
        delete e;
    } catch (logic_error *e) {
        cout << e->what() << endl;
        delete e;
    }
}

vector<Mesa*>* SalaDeTrabalhoCompartilhada::getMesasReservadas() {
    return mesasReserva;
}

double SalaDeTrabalhoCompartilhada::getPreco() {
    this->preco = 85*(mesasReserva->size());
    return preco;
}