#ifndef SALADETRABALHO_H
#define SALADETRABALHO_H

#include "Mesa.h"
#include "Sala.h"

#include <string>
#include <vector>
using namespace std;

// COMPLETE A DEFINICAO DA CLASSE
class SalaDeTrabalho : public Sala {
public:
    SalaDeTrabalho(string nome, int metragem);
    virtual ~SalaDeTrabalho();

    void adicionar(Mesa* m);
    vector<Mesa*>* getMesas();

    double getPreco();
private:
    vector<Mesa*>* mesas;
    double preco;
    double tamanhoDasMesas = 0;
    int quantidadeDeMesas = 0;
};

#endif // SALADETRABALHO_H
