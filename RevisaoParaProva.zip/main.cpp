/**
 * NAO ALTERE ESTE ARQUIVO
 */

void testeP2();

int main() {
  testeP2();
  return 0;
}
