#include <iostream>
#include <string>
using namespace std;


// Exercicio 1
string* recomendaProduto(string produtos[], int numeroDePedidos[], double precos[], int quantidade) {
int posicaoMaxPedido, maxPedido;
double maxPreco;
posicaoMaxPedido = 0;
maxPedido = numeroDePedidos[0];
maxPreco = precos[0];


for (int i = 0; i < quantidade; i++) {
    if (numeroDePedidos[i] > maxPedido) {
        maxPedido = numeroDePedidos[i];
        maxPreco = precos[i];
        posicaoMaxPedido = i;
    }
    else if (numeroDePedidos[i] == maxPedido && precos[i] > maxPreco) {
        maxPedido = numeroDePedidos[i];
        maxPreco = precos[i];
        posicaoMaxPedido = i;
    }
}


return &produtos[posicaoMaxPedido];
}


////////////////////////////////////////////
// REMOVA A MAIN ANTES DE ENVIAR AO JUDGE //
////////////////////////////////////////////
int main() {
string produtos[] = {"X-Burger", "X-Salada", "X-Bacon", "X-Tudo"};
int numeroDePedidos[] = {23, 78, 78, 50};
double precos[] = {10, 14.5, 15.90, 20};
int quantidade = 4;


cout << recomendaProduto(produtos, numeroDePedidos, precos, quantidade) << endl;
}
