#include <iostream> 
#include <string> 
#include <math.h> 
using namespace std; 

// Exercicio 2 
double calcularEstatisticas(string categorias[], double precos[], int quantidade, string categoria, double* precoMaximo, double& precoMinimo) { 
double precoMaximoTest = 0, precoMinimoTest = HUGE_VAL, media = 0; 
double precoSalvo = 0, quantidadeSalva; 

for (int j = 0; j < quantidade; j++) { 
    if (categorias[j] == categoria) { 
        precoSalvo += precos[j]; 
        quantidadeSalva ++; 
        if (precos[j] > precoMaximoTest) { 
            precoMaximoTest = precos[j]; 
        } 
        if (precos[j] < precoMinimoTest) { 
            precoMinimoTest = precos[j]; 
        } 
    } 
} 

if (precoMinimoTest == HUGE_VAL) { 
    precoMinimoTest = 0; 
} 

precoMinimo = precoMinimoTest; 
*precoMaximo = precoMaximoTest; 
media = precoSalvo/quantidadeSalva; 

return media; 
} 

////////////////////////////////////////////
// REMOVA A MAIN ANTES DE ENVIAR AO JUDGE //
////////////////////////////////////////////
int main() { 
string categorias[] = {"Sucos", "Legumes", "Sucos", "Detergentes"}; 
double precos[] = {3.5, 1.5, 2.9, 5}; 
int quantidade = 4; 
string categoria = "Sucos"; 
double precoMinimo = 0, precoMaximo = 0; 
double media = calcularEstatisticas(categorias, precos, quantidade, categoria, &precoMaximo, precoMinimo); 

cout << media << endl; 
cout << precoMaximo << endl; 
cout << precoMinimo << endl; 
} 